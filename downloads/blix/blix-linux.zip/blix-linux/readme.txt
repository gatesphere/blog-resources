blix
----
Jacob M. Peck, 2012 (http://suspended-chord.info/)

Attributions
------------
Original Blix game by LightForce (http://www.addictinggames.com/puzzle-games/blix.jsp)

Music by Kevin MacLeod ("Danse Morialta", available here: 
http://incompetech.com/m/c/royalty-free/index.html?keywords=Danse+Morialta&Search=Search)

License
-------
This game and related source code is released under a BSD license.  See license.txt 
for more details.

How to play
-----------
The object of blix is to make columns of blocks of the same color, by rotating rows
left and right.  Each row rotation eats up 1 move (you start with 4), but each matched 
column earns you another.

At 0 moves, it's game over.
You can't store any more than 12 moves.

When you rotate a row, the entire row moves over by one space in the direction
rotated, except for the block closest to the direction of rotation, which is
placed at the end of the row.  When a column is matched, all three of the blocks
are deleted, and every block to the left is shifted to the right into the new 
empty spaces.  A new column of three random blocks is placed into the far left
column.

High scrores are persisted across sessions, and are saved at the end of each game. 

Enjoy!