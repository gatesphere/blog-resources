// MSP430 Library for TI TLV5620 8-bit quad DAC
// version 20100906
// written by suspended-chord/gatesphere (http://suspended-chord.info/)
// released under the GNU GPLv3
#include <msp430.h>
#include "tlv5620.h"

void tlv5620_updateMode(unsigned char mode, char ldacPin, char ldacPort) {
  ldacPin = 1 << ldacPin;
  switch (ldacPort) {
    case 1:
      if (mode==SIMULTANEOUS)
        P1OUT |= ldacPin;
      else
        P1OUT &= ~ldacPin;
      break;
    case 2:
      if (mode==SIMULTANEOUS)
        P2OUT |= ldacPin;
      else
        P2OUT &= ~ldacPin;
      break;
  }
}

void tlv5620_simultaneousUpdate(char ldacPin, char ldacPort) {
  ldacPin = 1 << ldacPin;
  switch (ldacPort) {
    case 1:
      P1OUT &= ~ldacPin;
      P1OUT |= ldacPin;
      break;
    case 2:
      P2OUT &= ~ldacPin;
      P2OUT |= ldacPin;
      break;
  }
}

void tlv5620_sendData(unsigned char dacSel, unsigned char gainSel, unsigned char value,
                      char clockPin, char clockPort, 
                      char dataPin, char dataPort,
                      char loadPin, char loadPort) {
  int i, temp; // for looping                  
  
  int data = ((dacSel + gainSel) << 8) + value; // set up 11-bit control word
  
  clockPin = 1 << clockPin;
  dataPin = 1 << dataPin;
  loadPin = 1 << loadPin;
  
  switch (loadPort) {  // take loadPin high to allow data streaming
    case 1:
      P1OUT |= loadPin;
      break;
    case 2:
      P2OUT |= loadPin;
      break;
  }
  
  for (i = 0; i < 11; i++) { // 11 bit control word
    switch (clockPort) { // toggle clock
      case 1:
        P1OUT |= clockPin;
        break;
      case 2:
        P2OUT |= clockPin;
        break;
    }
    
    temp = (data&1024) >> 10; // MSB first of 11 bit control word

    switch (dataPort) { // write bit
      case 1:
        if (temp == 0)
          P1OUT &= ~dataPin;
        else
          P1OUT |= dataPin;
        break;
      case 2:
        if (temp == 0)
          P2OUT &= ~dataPin;
        else
          P2OUT |= dataPin;
        break;
    }
    
    switch (clockPort) { // toggle clock
      case 1:
        P1OUT &= ~clockPin;
        break;
      case 2:
        P2OUT &= ~clockPin;
        break;
    }
    
    data = data << 1; // shift data left 1 bit
  }
  
  switch (loadPort) {  // take loadPin low to shift out data
    case 1:
      P1OUT &= ~loadPin;
      break;
    case 2:
      P2OUT &= ~loadPin;
      break;
  }
}
