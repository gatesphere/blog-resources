// MSP430 Library for TI TLV5620 8-bit quad DAC
// version 20100906
// written by suspended-chord/gatesphere (http://suspended-chord.info/)
// released under the GNU GPLv3
#include <msp430.h>

#ifndef TLV5620_H_
#define TLV5620_H_

#define GAIN1X          0  // 0b00000000
#define GAIN2X          1  // 0b00000001
#define DACA            0  // 0b00000000
#define DACB            2  // 0b00000010
#define DACC            4  // 0b00000100
#define DACD            6  // 0b00000110
#define SIMULTANEOUS    1
#define ASYNCHRONOUS    0

void tlv5620_updateMode(unsigned char mode, char ldacPin, char ldacPort);
void tlv5620_simultaneousUpdate(char ldacPin, char ldacPort);
void tlv5620_sendData(unsigned char dacSel, unsigned char gainSel, unsigned char value, 
                      char clockPin, char clockPort, char dataPin, char dataPort, 
                      char loadPin, char loadPort);

#endif /*TLV5620_H_*/
