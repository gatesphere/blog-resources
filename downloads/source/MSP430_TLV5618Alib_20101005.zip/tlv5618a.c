// MSP430 Library for TI TLV5618A 12-bit dual DAC
// version 20101005
// written by suspended-chord/gatesphere (http://suspended-chord.info/)
// released under the GNU GPLv3
#include <msp430.h>
#include "tlv5618a.h"

void tlv5618a_powerDown(char clockPin, char clockPort, char dataPin, char dataPort,
                        char latchPin, char latchPort) {
  tlv5618a_sendData(0,0,POWERDOWN,clockPin,clockPort,dataPin,dataPort,latchPin,latchPort);
}

void tlv5618a_sendData(unsigned int dacSel, unsigned int speedSel, unsigned int value,
                      char clockPin, char clockPort, 
                      char dataPin, char dataPort,
                      char latchPin, char latchPort) {
  int i, temp; // for looping
  unsigned int data;
  
  if (value > 4095) value = 4095; // clamp data within range
  
  data = dacSel + speedSel + value; // set up 16-bit control word
  
  clockPin = 1 << clockPin;
  dataPin = 1 << dataPin;
  latchPin = 1 << latchPin;
  
  switch (latchPort) {  // take latchPin low to allow data streaming
    case 1:
      P1OUT &= ~latchPin;
      break;
    case 2:
      P2OUT &= ~latchPin;
      break;
  }
  
  for (i = 0; i < 16; i++) { // 16 bit control word
    switch (clockPort) { // toggle clock
      case 1:
        P1OUT |= clockPin;
        break;
      case 2:
        P2OUT |= clockPin;
        break;
    }
    
    temp = (data&0xFFFF) >> 15; // MSB first of 16 bit control word

    switch (dataPort) { // write bit
      case 1:
        if (temp == 0)
          P1OUT &= ~dataPin;
        else
          P1OUT |= dataPin;
        break;
      case 2:
        if (temp == 0)
          P2OUT &= ~dataPin;
        else
          P2OUT |= dataPin;
        break;
    }
    
    switch (clockPort) { // toggle clock
      case 1:
        P1OUT &= ~clockPin;
        break;
      case 2:
        P2OUT &= ~clockPin;
        break;
    }
    
    data = data << 1; // shift data left 1 bit
  }
  
  switch (clockPort) { // pulse clock high once more, as per datasheet
      case 1:
        P1OUT |= clockPin;
        break;
      case 2:
        P2OUT |= clockPin;
        break;
  }
  
  switch (latchPort) {  // take latchPin high to shift out data
    case 1:
      P1OUT |= latchPin;
      break;
    case 2:
      P2OUT |= latchPin;
      break;
  }
}
