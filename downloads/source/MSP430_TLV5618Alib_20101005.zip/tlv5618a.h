// MSP430 Library for TI TLV5618A 12-bit dual DAC
// version 20101005
// written by suspended-chord/gatesphere (http://suspended-chord.info/)
// released under the GNU GPLv3
#include <msp430.h>

#ifndef TLV5618A_H_
#define TLV5618A_H_

#define DACA        0x8000 // 0b10000000 00000000
#define DACB        0x0000 // 0b00000000 00000000
#define DACBUFFER   0x1000 // 0b00010000 00000000
#define FAST        0x4000 // 0b01000000 00000000
#define SLOW        0x0000 // 0b00000000 00000000
#define POWERDOWN   0x2000 // 0b00100000 00000000

void tlv5618a_powerDown(char clockPin, char clockPort, char dataPin, char dataPort,
                        char latchPin, char latchPort);
void tlv5618a_sendData(unsigned int dacSel, unsigned int speedSel, unsigned int value,
                       char clockPin, char clockPort, char dataPin, char dataPort,
                       char latchPin, char latchPort);
 

#endif /*TLV5618A_H_*/
